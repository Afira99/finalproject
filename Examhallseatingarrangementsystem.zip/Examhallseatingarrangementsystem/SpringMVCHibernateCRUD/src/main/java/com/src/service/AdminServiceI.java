package com.src.service;

import com.src.model.Admin;

public interface AdminServiceI {

	
	public boolean validate(Admin admin);
}
